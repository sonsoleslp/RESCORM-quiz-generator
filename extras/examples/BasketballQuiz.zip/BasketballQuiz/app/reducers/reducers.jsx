import {combineReducers} from 'redux';
import trackingReducer from './trackingReducer';
import scormReducer from './scormReducer';
import userProfileReducer from './userProfileReducer';
import waitForUserProfileReducer from './waitForUserProfileReducer';
import jsonSavedReducer from './jsonSavedReducer';
import initialScreenReducer from './initialScreenReducer';

const GlobalState = combineReducers({
  tracking:trackingReducer,
  scorm:scormReducer,
  user_profile:userProfileReducer,
  wait_for_user_profile:waitForUserProfileReducer,
  jsoninterno:jsonSavedReducer,
  initial_screen: initialScreenReducer,
});

export default GlobalState;